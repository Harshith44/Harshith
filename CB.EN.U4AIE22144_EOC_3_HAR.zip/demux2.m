% DEMUX 1 TO 2 FUNCTION
function z = demux2(in,s0)
if in <= 1 && s0 <= 1
    a = andgate(in,notgate(s0));
    b = andgate(in,s0);
    z=[a b];
else 
    fprintf("INVALID ,ENTER 0 OR 1")
end
end
