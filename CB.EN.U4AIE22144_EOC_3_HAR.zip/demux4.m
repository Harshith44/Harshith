% DEMUX 4 TO 1 FUNCTION
function z = demux4(in,s0,s1)
if in<=1 && s0<=1 && s1<=1
    x = notgate(s0);
    y = notgate(s1);

    a = andgate(in,(andgate(x,y)));
    b = andgate(in,(andgate(x,s1)));
    c = andgate(in,(andgate(s0,y)));
    d = andgate(in,(andgate(s0,s1)));
    
    z = [a b c d];
else
    fprintf("INVALID ,ENTER 0 OR 1")
end
end